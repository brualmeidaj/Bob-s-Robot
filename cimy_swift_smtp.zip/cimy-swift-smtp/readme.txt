=== Cimy Swift SMTP ===
Contributors: Marco Cimmino
Donate link: http://www.marcocimmino.net/cimy-wordpress-plugins/support-the-cimy-project-paypal/
Website link: http://www.marcocimmino.net/cimy-wordpress-plugins/cimy-swift-smtp/
Tags: cimy, email, smtp, gmail, swift, admin
Requires at least: 4.0
Tested up to: 4.8
Stable tag: 3.0.2

Send email via SMTP (Compatible with GMAIL)

== Description ==

This plug-in is for all people that have an hosting server with the php default mail function disabled and/or want to use their own SMTP servers.
Supports SSL/TLS/STARTTLS encryption methods.
Uses Swift Mailer engine - http://swiftmailer.org/

== Frequently Asked Questions ==

= I have a lot of questions and I want support where can I go? =

http://www.marcocimmino.net/cimy-wordpress-plugins/cimy-swift-smtp/faq-and-comments/

== Installation ==

Just copy the plug-in in your plug-in directory and activate it

== Screenshots ==

1. Options page

== Changelog ==

http://www.marcocimmino.net/cimy-wordpress-plugins/cimy-swift-smtp/all-versions-and-changelog/
